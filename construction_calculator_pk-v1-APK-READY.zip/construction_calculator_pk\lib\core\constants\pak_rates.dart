// Pakistan default market rates - editable in app + Remote Config later
class PakRates {
  static double cementPerBag = 1450; // PKR 50kg Lucky/Bestway
  static double steelPerKg = 280;
  static double sandPerCft = 80;
  static double crushPerCft = 120;
  static double brickPerPc = 18;
  static double paintPerLiter = 1200;
  static double labourPerDay = 1500;

  static Map<String, double> cityMultiplier = {
    'Lahore': 1.0,
    'Karachi': 1.05,
    'Islamabad': 1.12,
    'Multan': 0.92,
    'Faisalabad': 0.95,
    'Peshawar': 0.98,
    'Quetta': 1.02,
  };

  static double forCity(double base, String city) {
    return base * (cityMultiplier[city] ?? 1.0);
  }
}
