import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/constants/app_colors.dart';
import '../../widgets/common.dart';

class TankScreen extends StatefulWidget { const TankScreen({super.key}); @override State<TankScreen> createState()=> _S();}
class _S extends State<TankScreen> {
  final lCtrl=TextEditingController(text:'8'), lInCtrl=TextEditingController(text:'0');
  final wCtrl=TextEditingController(text:'6'), wInCtrl=TextEditingController(text:'0');
  final hCtrl=TextEditingController(text:'5'), hInCtrl=TextEditingController(text:'0');
  double? volCft;
  void calc(){ double l=(double.tryParse(lCtrl.text)??0)+(double.tryParse(lInCtrl.text)??0)/12; double w=(double.tryParse(wCtrl.text)??0)+(double.tryParse(wInCtrl.text)??0)/12; double h=(double.tryParse(hCtrl.text)??0)+(double.tryParse(hInCtrl.text)??0)/12; setState(()=> volCft=l*w*h); }
  @override Widget build(BuildContext context){
    return Scaffold(backgroundColor: AppColors.bg, appBar: AppBar(title: const Text('Water / Septic Tank'), backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        FeetInchInput(label: 'Length', ftCtrl: lCtrl, inchCtrl: lInCtrl),
        FeetInchInput(label: 'Width', ftCtrl: wCtrl, inchCtrl: wInCtrl),
        FeetInchInput(label: 'Depth / Height', ftCtrl: hCtrl, inchCtrl: hInCtrl),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: calc, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical:16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('CALCULATE TANK', style: TextStyle(fontWeight: FontWeight.w800)))),
        if(volCft!=null)...[
          const SizedBox(height:16),
          ResultTile(title: 'Volume', value: '${volCft!.toStringAsFixed(1)} cft', subtitle: '${(volCft!*28.3168).toStringAsFixed(0)} liters', icon: Icons.water_drop, color: const Color(0xFF0097A7)),
          const SizedBox(height:10),
          ResultTile(title: 'Capacity', value: '${(volCft!*7.48052).toStringAsFixed(0)} US gallons', subtitle: '${(volCft!*6.2288).toStringAsFixed(0)} UK gallons • ${(volCft!*28.3168/1000).toStringAsFixed(2)} m³', icon: Icons.opacity),
          const SizedBox(height:10),
          Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)), child: const Text('Tip: For septic tank, keep depth <6ft for easy cleaning. Add 1ft freeboard.', style: TextStyle(fontSize:11, color: Color(0xFF6B6B6B)))),
          const SizedBox(height:10),
          SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: (){ Share.share('Tank ${lCtrl.text}x${wCtrl.text}x${hCtrl.text} ft = ${volCft!.toStringAsFixed(1)} cft = ${(volCft!*28.3168).toStringAsFixed(0)} liters'); }, icon: const Icon(Icons.share), label: const Text('Share on WhatsApp'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white)))
        ]
      ]));
  }
}
