// Simple l10n - replace with easy_localization later
class Strings {
  static const en = {
    'appTitle': 'Construction Calculator',
    'subtitle': 'Pakistan • PKR • Offline',
    'calculate': 'CALCULATE',
    'share': 'Share on WhatsApp',
  };
  static const ur = {
    'appTitle': 'کنسٹرکشن کیلکولیٹر',
    'subtitle': 'پاکستان • روپے • آف لائن',
    'calculate': 'حساب کریں',
    'share': 'واٹس ایپ پر شیئر کریں',
  };
}
