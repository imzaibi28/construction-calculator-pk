import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/constants/app_colors.dart';
import '../../widgets/common.dart';

class ExcavationScreen extends StatefulWidget { const ExcavationScreen({super.key}); @override State<ExcavationScreen> createState()=> _S();}
class _S extends State<ExcavationScreen> {
  final lCtrl=TextEditingController(text:'30'), lInCtrl=TextEditingController(text:'0');
  final wCtrl=TextEditingController(text:'20'), wInCtrl=TextEditingController(text:'0');
  final dCtrl=TextEditingController(text:'5'), dInCtrl=TextEditingController(text:'0');
  double? vol;
  void calc(){ double l=(double.tryParse(lCtrl.text)??0)+(double.tryParse(lInCtrl.text)??0)/12; double w=(double.tryParse(wCtrl.text)??0)+(double.tryParse(wInCtrl.text)??0)/12; double d=(double.tryParse(dCtrl.text)??0)+(double.tryParse(dInCtrl.text)??0)/12; setState(()=> vol=l*w*d); }
  @override Widget build(BuildContext context){
    return Scaffold(backgroundColor: AppColors.bg, appBar: AppBar(title: const Text('Excavation / Khudai'), backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        FeetInchInput(label: 'Length', ftCtrl: lCtrl, inchCtrl: lInCtrl),
        FeetInchInput(label: 'Width', ftCtrl: wCtrl, inchCtrl: wInCtrl),
        FeetInchInput(label: 'Depth', ftCtrl: dCtrl, inchCtrl: dInCtrl),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: calc, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical:16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('CALCULATE EXCAVATION', style: TextStyle(fontWeight: FontWeight.w800)))),
        if(vol!=null)...[
          const SizedBox(height:16),
          ResultTile(title: 'Excavation Volume', value: '${vol!.toStringAsFixed(1)} cft', subtitle: '${(vol!*0.0283168).toStringAsFixed(2)} m³', icon: Icons.landscape, color: const Color(0xFF8B5A2B)),
          const SizedBox(height:10),
          ResultTile(title: 'Truck Trips (Trolley)', value: '${(vol!/500).ceil()} trips', subtitle: '500 cft per trolley • 1 tractor trolley', icon: Icons.local_shipping),
          const SizedBox(height:10),
          ResultTile(title: 'Labour Estimate', value: '${(vol!/200).ceil()} mazdoor-days', subtitle: '~200 cft per mazdoor per day', icon: Icons.groups),
          const SizedBox(height:10),
          SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: (){ Share.share('Excavation ${lCtrl.text}x${wCtrl.text}x${dCtrl.text} ft = ${vol!.toStringAsFixed(1)} cft, ${(vol!/500).ceil()} trolley trips'); }, icon: const Icon(Icons.share), label: const Text('Share on WhatsApp'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white)))
        ]
      ]));
  }
}
