import 'package:flutter/material.dart';
import '../core/constants/app_colors.dart';

class InputCard extends StatelessWidget {
  final String label;
  final Widget child;
  const InputCard({super.key, required this.label, required this.child});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: AppColors.textGrey)),
        const SizedBox(height: 8),
        child,
      ]),
    );
  }
}

class ResultTile extends StatelessWidget {
  final String title; final String value; final String subtitle; final IconData icon; final Color color;
  const ResultTile({super.key, required this.title, required this.value, required this.subtitle, required this.icon, this.color = AppColors.accent});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: color.withOpacity(0.2))),
      child: Row(children: [
        Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(10)), child: Icon(icon, color: color)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 12, color: AppColors.textGrey)),
          Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.textGrey)),
        ]))
      ]),
    );
  }
}

class LabeledTextField extends StatelessWidget {
  final String hint; final TextEditingController controller; final String suffix;
  const LabeledTextField({super.key, required this.hint, required this.controller, this.suffix='ft'});
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        hintText: hint,
        suffixText: suffix,
        filled: true, fillColor: const Color(0xFFF2F2F2),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      ),
    );
  }
}

class FeetInchInput extends StatelessWidget {
  final String label;
  final TextEditingController ftCtrl;
  final TextEditingController inchCtrl;
  const FeetInchInput({super.key, required this.label, required this.ftCtrl, required this.inchCtrl});
  @override
  Widget build(BuildContext context) {
    return InputCard(label: label, child: Row(children: [
      Expanded(child: LabeledTextField(hint: '0', controller: ftCtrl, suffix: 'ft')),
      const SizedBox(width: 8),
      Expanded(child: LabeledTextField(hint: '0', controller: inchCtrl, suffix: 'in')),
    ]));
  }
}
