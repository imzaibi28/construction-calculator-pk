class PakFormulas {
  // Concrete: L*W*H in feet -> cft. Dry vol 1.54
  static Map<String, double> concrete(double l, double w, double h, List<int> ratio) {
    double wet = l * w * h;
    double dry = wet * 1.54;
    int sum = ratio.reduce((a, b) => a + b);
    double cementCft = dry * ratio[0] / sum;
    double sandCft = dry * ratio[1] / sum;
    double crushCft = dry * ratio[2] / sum;
    double cementBags = cementCft / 1.25; // 1 bag = 1.25 cft
    return {
      'wet': wet,
      'dry': dry,
      'cementBags': cementBags,
      'sandCft': sandCft,
      'crushCft': crushCft,
    };
  }

  static Map<String, double> bricks(double l, double h, double thick) {
    double vol = l * h * thick;
    double qty = (vol / 0.071) * 1.05; // 5% wastage
    double mortarCft = vol * 0.25;
    double cementBags = (mortarCft * 1 / 7) / 1.25; // 1:6
    double sandCft = mortarCft * 6 / 7;
    return {'bricks': qty, 'cementBags': cementBags, 'sandCft': sandCft, 'vol': vol};
  }

  static double steelWeightKg(double diaMm, double lengthFt) {
    double lengthM = lengthFt * 0.3048;
    return (diaMm * diaMm / 162) * lengthM;
  }

  static double paintLiters(double areaSqft, int coats, double coverage) {
    return areaSqft / coverage * coats * 1.1;
  }

  static double tilesQty(double roomL, double roomW, double tileLft, double tileWft) {
    double roomArea = roomL * roomW;
    double tileArea = tileLft * tileWft;
    return (roomArea / tileArea) * 1.10;
  }

  static Map<String, double> plaster(double areaSqft, double thickFt, List<int> ratio) {
    double vol = areaSqft * thickFt;
    int sum = ratio.reduce((a, b) => a + b);
    double cementBags = (vol * ratio[0] / sum) / 1.25;
    double sandCft = vol * ratio[1] / sum;
    return {'cementBags': cementBags, 'sandCft': sandCft, 'vol': vol};
  }

  static String formatPKR(double v) {
    if (v >= 10000000) return 'Rs. ${(v/10000000).toStringAsFixed(2)} Crore';
    if (v >= 100000) return 'Rs. ${(v/100000).toStringAsFixed(2)} Lakh';
    return 'Rs. ${v.toStringAsFixed(0)}';
  }
}
