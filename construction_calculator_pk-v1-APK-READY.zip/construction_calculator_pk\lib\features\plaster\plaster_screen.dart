import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/pak_rates.dart';
import '../../core/utils/formulas.dart';
import '../../widgets/common.dart';

class PlasterScreen extends StatefulWidget { const PlasterScreen({super.key}); @override State<PlasterScreen> createState()=> _S();}
class _S extends State<PlasterScreen> {
  final aCtrl=TextEditingController(text:'500'); // sqft
  String thick='12mm (0.5")'; String ratio='1:4'; String city='Lahore';
  Map<String,double>? res;
  void calc(){
    double area=double.tryParse(aCtrl.text)??0;
    double tFt= thick.contains('12')?0.04: thick.contains('15')?0.05:0.04;
    List<int> r= ratio=='1:4'?[1,4]: ratio=='1:5'?[1,5]:[1,6];
    setState(()=> res=PakFormulas.plaster(area, tFt, r));
  }
  @override Widget build(BuildContext context){
    return Scaffold(backgroundColor: AppColors.bg, appBar: AppBar(title: const Text('Plaster / Chunai'), backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        InputCard(label: 'Wall/Ceiling Area (sqft)', child: LabeledTextField(hint: '500', controller: aCtrl, suffix: 'sqft')),
        InputCard(label: 'Thickness', child: DropdownButton<String>(value: thick, isExpanded: true, items: const [DropdownMenuItem(value:'12mm (0.5")', child: Text('12mm - Interior (0.5 inch)')), DropdownMenuItem(value:'15mm (0.6")', child: Text('15mm - Exterior (0.6 inch)'))], onChanged: (v)=>setState(()=>thick=v!))),
        InputCard(label: 'Cement:Sand Ratio', child: DropdownButton<String>(value: ratio, isExpanded: true, items: const [DropdownMenuItem(value:'1:4', child: Text('1:4 - Standard')), DropdownMenuItem(value:'1:5', child: Text('1:5 - Economy')), DropdownMenuItem(value:'1:6', child: Text('1:6 - Ceiling'))], onChanged: (v)=>setState(()=>ratio=v!))),
        InputCard(label: 'City', child: DropdownButton<String>(value: city, isExpanded: true, items: PakRates.cityMultiplier.keys.map((e)=>DropdownMenuItem(value:e, child: Text(e))).toList(), onChanged: (v)=>setState(()=>city=v!))),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: calc, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical:16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('CALCULATE PLASTER', style: TextStyle(fontWeight: FontWeight.w800)))),
        if(res!=null)...[
          const SizedBox(height:16),
          ResultTile(title: 'Cement', value: '${res!['cementBags']!.toStringAsFixed(2)} bags', subtitle: '50kg • ${res!['cementBags']!.ceil()} bags order', icon: Icons.inventory_2, color: const Color(0xFF6A5AE0)),
          const SizedBox(height:10),
          ResultTile(title: 'Sand', value: '${res!['sandCft']!.toStringAsFixed(1)} cft', subtitle: 'Fine sand (Chenab)', icon: Icons.landscape, color: const Color(0xFFD4A017)),
          const SizedBox(height:10),
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.primaryDark, borderRadius: BorderRadius.circular(14)), child: Builder(builder: (_){
            double c=res!['cementBags']!*PakRates.forCity(PakRates.cementPerBag,city); double s=res!['sandCft']!*PakRates.forCity(PakRates.sandPerCft,city); double tot=c+s;
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children:[const Text('TOTAL COST', style: TextStyle(color: Colors.white70, fontSize:11)), Text(PakFormulas.formatPKR(tot), style: const TextStyle(color: AppColors.primary, fontSize:22, fontWeight: FontWeight.w900)), Text('Cement ${PakFormulas.formatPKR(c)} + Sand ${PakFormulas.formatPKR(s)}', style: const TextStyle(color: Colors.white70, fontSize:11)), const SizedBox(height:10), SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: (){ Share.share('Plaster ${aCtrl.text} sqft $thick $ratio: Cement ${res!['cementBags']!.toStringAsFixed(1)} bags, Sand ${res!['sandCft']!.toStringAsFixed(1)} cft - ${PakFormulas.formatPKR(tot)}'); }, icon: const Icon(Icons.share), label: const Text('Share on WhatsApp'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white)))]);
          }))
        ]
      ]));
  }
}
