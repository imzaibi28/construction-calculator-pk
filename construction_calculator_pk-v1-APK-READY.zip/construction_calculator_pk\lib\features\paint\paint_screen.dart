import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/pak_rates.dart';
import '../../core/utils/formulas.dart';
import '../../widgets/common.dart';

class PaintScreen extends StatefulWidget { const PaintScreen({super.key}); @override State<PaintScreen> createState()=> _S();}
class _S extends State<PaintScreen> {
  final aCtrl=TextEditingController(text:'1000'); String coats='2'; String city='Lahore';
  double? liters;
  void calc(){ double area=double.tryParse(aCtrl.text)??0; setState(()=> liters=PakFormulas.paintLiters(area, int.parse(coats), 350)); }
  @override Widget build(BuildContext context){
    return Scaffold(backgroundColor: AppColors.bg, appBar: AppBar(title: const Text('Paint Calculator'), backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        InputCard(label: 'Total Wall Area (sqft)', child: LabeledTextField(hint: '1000', controller: aCtrl, suffix: 'sqft')),
        InputCard(label: 'Coats', child: DropdownButton<String>(value: coats, isExpanded: true, items: const [DropdownMenuItem(value:'1', child: Text('1 Coat - Primer only')), DropdownMenuItem(value:'2', child: Text('2 Coats - Standard')), DropdownMenuItem(value:'3', child: Text('3 Coats - Premium'))], onChanged: (v)=>setState(()=>coats=v!))),
        InputCard(label: 'Brands coverage ~350 sqft/L', child: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: const Color(0xFFF2F2F2), borderRadius: BorderRadius.circular(10)), child: const Text('Master • Berger • Diamond • Brighto • +10% wastage included', style: TextStyle(fontSize:11)))),
        InputCard(label: 'City', child: DropdownButton<String>(value: city, isExpanded: true, items: PakRates.cityMultiplier.keys.map((e)=>DropdownMenuItem(value:e, child: Text(e))).toList(), onChanged: (v)=>setState(()=>city=v!))),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: calc, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical:16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('CALCULATE PAINT', style: TextStyle(fontWeight: FontWeight.w800)))),
        if(liters!=null)...[
          const SizedBox(height:16),
          ResultTile(title: 'Paint Required', value: '${liters!.toStringAsFixed(1)} liters', subtitle: '${(liters!/4).toStringAsFixed(1)} gallons • $coats coats', icon: Icons.brush, color: const Color(0xFF6A5AE0)),
          const SizedBox(height:10),
          ResultTile(title: 'Drums (20L)', value: '${(liters!/20).ceil()} drums', subtitle: '20L plastic emulsion', icon: Icons.inventory),
          const SizedBox(height:10),
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.primaryDark, borderRadius: BorderRadius.circular(14)), child: Builder(builder: (_){
            double tot=liters!*PakRates.forCity(PakRates.paintPerLiter,city);
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children:[const Text('ESTIMATED COST', style: TextStyle(color: Colors.white70, fontSize:11)), Text(PakFormulas.formatPKR(tot), style: const TextStyle(color: AppColors.primary, fontSize:22, fontWeight: FontWeight.w900)), Text('@ Rs.${PakRates.forCity(PakRates.paintPerLiter,city).toStringAsFixed(0)}/L in $city', style: const TextStyle(color: Colors.white70, fontSize:11)), const SizedBox(height:10), SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: (){ Share.share('Paint ${aCtrl.text} sqft $coats coats: ${liters!.toStringAsFixed(1)} liters, Cost ${PakFormulas.formatPKR(tot)}'); }, icon: const Icon(Icons.share), label: const Text('Share on WhatsApp'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white)))]);
          }))
        ]
      ]));
  }
}
