import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/pak_rates.dart';
import '../../core/utils/formulas.dart';
import '../../widgets/common.dart';

class BrickScreen extends StatefulWidget {
  const BrickScreen({super.key});
  @override State<BrickScreen> createState()=> _BrickScreenState();
}
class _BrickScreenState extends State<BrickScreen> {
  final lCtrl=TextEditingController(text:'20'), lInCtrl=TextEditingController(text:'0');
  final hCtrl=TextEditingController(text:'10'), hInCtrl=TextEditingController(text:'0');
  String thick='4.5 inch (single)';
  String city='Lahore';
  Map<String,double>? res;
  double thickFt()=> thick.contains('4.5')?0.375:0.75;
  void calc(){
    double l=(double.tryParse(lCtrl.text)??0)+(double.tryParse(lInCtrl.text)??0)/12;
    double h=(double.tryParse(hCtrl.text)??0)+(double.tryParse(hInCtrl.text)??0)/12;
    setState(()=> res=PakFormulas.bricks(l,h,thickFt()));
  }
  @override Widget build(BuildContext context){
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('Brick Calculator'), backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        FeetInchInput(label: 'Wall Length', ftCtrl: lCtrl, inchCtrl: lInCtrl),
        FeetInchInput(label: 'Wall Height', ftCtrl: hCtrl, inchCtrl: hInCtrl),
        InputCard(label: 'Wall Thickness', child: DropdownButton<String>(value: thick, isExpanded: true, items: const [DropdownMenuItem(value:'4.5 inch (single)', child: Text('4.5 inch - Single brick')), DropdownMenuItem(value:'9 inch (double)', child: Text('9 inch - Double brick (load bearing)'))], onChanged: (v)=>setState(()=>thick=v!))),
        InputCard(label: 'City', child: DropdownButton<String>(value: city, isExpanded: true, items: PakRates.cityMultiplier.keys.map((e)=>DropdownMenuItem(value:e, child: Text(e))).toList(), onChanged: (v)=>setState(()=>city=v!))),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: calc, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical:16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('CALCULATE BRICKS', style: TextStyle(fontWeight: FontWeight.w800)))),
        if(res!=null)...[
          const SizedBox(height:16),
          ResultTile(title: 'Bricks Required', value: '${res!['bricks']!.toStringAsFixed(0)} bricks', subtitle: 'With 5% wastage • Std 9x4.5x3\"', icon: Icons.wall, color: const Color(0xFFD44B2E)),
          const SizedBox(height:10),
          ResultTile(title: 'Cement for Mortar (1:6)', value: '${res!['cementBags']!.toStringAsFixed(2)} bags', subtitle: '50kg bags', icon: Icons.inventory_2),
          const SizedBox(height:10),
          ResultTile(title: 'Sand for Mortar', value: '${res!['sandCft']!.toStringAsFixed(1)} cft', subtitle: 'Rait', icon: Icons.landscape, color: const Color(0xFFD4A017)),
          const SizedBox(height:10),
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.primaryDark, borderRadius: BorderRadius.circular(14)), child: Builder(builder: (_){
            double bCost=res!['bricks']!*PakRates.forCity(PakRates.brickPerPc,city);
            double cCost=res!['cementBags']!*PakRates.forCity(PakRates.cementPerBag,city);
            double sCost=res!['sandCft']!*PakRates.forCity(PakRates.sandPerCft,city);
            double tot=bCost+cCost+sCost;
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
              const Text('TOTAL COST', style: TextStyle(color: Colors.white70, fontSize:11)),
              Text(PakFormulas.formatPKR(tot), style: const TextStyle(color: AppColors.primary, fontSize:22, fontWeight: FontWeight.w900)),
              Text('Bricks ${PakFormulas.formatPKR(bCost)} + Cement ${PakFormulas.formatPKR(cCost)} + Sand ${PakFormulas.formatPKR(sCost)}', style: const TextStyle(color: Colors.white70, fontSize:11)),
              const SizedBox(height:10),
              SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: (){ Share.share('Brick Wall ${lCtrl.text}ft x ${hCtrl.text}ft: ${res!['bricks']!.toStringAsFixed(0)} bricks, Cost ${PakFormulas.formatPKR(tot)}'); }, icon: const Icon(Icons.share), label: const Text('Share on WhatsApp'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white)))
            ]);
          }))
        ]
      ]),
    );
  }
}
