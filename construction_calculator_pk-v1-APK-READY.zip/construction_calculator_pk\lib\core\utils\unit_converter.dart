class UnitConverter {
  // Feet+Inch string parsing: "10 ft 6 in" or 10.5
  static double feetInchToFeet(int ft, int inch) => ft + inch / 12.0;
  static String feetToFeetInch(double ft) {
    int f = ft.floor();
    int inch = ((ft - f) * 12).round();
    if (inch == 12) { f++; inch = 0; }
    return inch == 0 ? '$f ft' : '$f ft $inch in';
  }
  static double cftToM3(double cft) => cft * 0.0283168;
  static double sqftToSqm(double sqft) => sqft * 0.092903;
}
