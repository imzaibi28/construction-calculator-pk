import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/pak_rates.dart';
import '../../core/utils/formulas.dart';
import '../../widgets/common.dart';

class TilesScreen extends StatefulWidget { const TilesScreen({super.key}); @override State<TilesScreen> createState()=> _S();}
class _S extends State<TilesScreen> {
  final lCtrl=TextEditingController(text:'12'), lInCtrl=TextEditingController(text:'0');
  final wCtrl=TextEditingController(text:'10'), wInCtrl=TextEditingController(text:'0');
  String tileSize='24x24 inch (2x2 ft)'; String city='Lahore';
  double? qty;
  void calc(){
    double l=(double.tryParse(lCtrl.text)??0)+(double.tryParse(lInCtrl.text)??0)/12;
    double w=(double.tryParse(wCtrl.text)??0)+(double.tryParse(wInCtrl.text)??0)/12;
    double tl=1, tw=1;
    if(tileSize.contains('12x12')){tl=1; tw=1;} else if(tileSize.contains('24x24')){tl=2; tw=2;} else if(tileSize.contains('24x12')){tl=2; tw=1;}
    setState(()=> qty=PakFormulas.tilesQty(l,w,tl,tw));
  }
  @override Widget build(BuildContext context){
    return Scaffold(backgroundColor: AppColors.bg, appBar: AppBar(title: const Text('Tiles / Flooring'), backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        FeetInchInput(label: 'Room Length', ftCtrl: lCtrl, inchCtrl: lInCtrl),
        FeetInchInput(label: 'Room Width', ftCtrl: wCtrl, inchCtrl: wInCtrl),
        InputCard(label: 'Tile Size', child: DropdownButton<String>(value: tileSize, isExpanded: true, items: const [DropdownMenuItem(value:'12x12 inch (1x1 ft)', child: Text('12x12 inch - Bathroom')), DropdownMenuItem(value:'24x12 inch (2x1 ft)', child: Text('24x12 inch - Wall')), DropdownMenuItem(value:'24x24 inch (2x2 ft)', child: Text('24x24 inch - Floor (standard)'))], onChanged: (v)=>setState(()=>tileSize=v!))),
        InputCard(label: 'City', child: DropdownButton<String>(value: city, isExpanded: true, items: PakRates.cityMultiplier.keys.map((e)=>DropdownMenuItem(value:e, child: Text(e))).toList(), onChanged: (v)=>setState(()=>city=v!))),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: calc, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical:16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('CALCULATE TILES', style: TextStyle(fontWeight: FontWeight.w800)))),
        if(qty!=null)...[
          const SizedBox(height:16),
          ResultTile(title: 'Tiles Required', value: '${qty!.ceil()} tiles', subtitle: '$tileSize +10% wastage', icon: Icons.grid_on, color: const Color(0xFF2E86AB)),
          const SizedBox(height:10),
          ResultTile(title: 'Floor Area', value: '${((double.tryParse(lCtrl.text)??0)*(double.tryParse(wCtrl.text)??0)).toStringAsFixed(0)} sqft', subtitle: 'Room area', icon: Icons.square_foot),
          const SizedBox(height:10),
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.primaryDark, borderRadius: BorderRadius.circular(14)), child: Builder(builder: (_){
            double area=(double.tryParse(lCtrl.text)??0)*(double.tryParse(wCtrl.text)??0); double tot=area*PakRates.forCity(85,city);
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children:[const Text('TILES COST (est.)', style: TextStyle(color: Colors.white70, fontSize:11)), Text(PakFormulas.formatPKR(tot), style: const TextStyle(color: AppColors.primary, fontSize:22, fontWeight: FontWeight.w900)), Text('@ Rs.85/sqft in $city • Master/Timocer', style: const TextStyle(color: Colors.white70, fontSize:11)), const SizedBox(height:10), SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: (){ Share.share('Tiles ${lCtrl.text}x${wCtrl.text} ft $tileSize: ${qty!.ceil()} tiles, Cost ${PakFormulas.formatPKR(tot)}'); }, icon: const Icon(Icons.share), label: const Text('Share on WhatsApp'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white)))]);
          }))
        ]
      ]));
  }
}
