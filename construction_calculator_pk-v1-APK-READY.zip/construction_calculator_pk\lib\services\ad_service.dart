import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

// Test IDs - replace with real AdMob IDs before Play Store release
class AdService {
  static const bannerTestId = 'ca-app-pub-3940256099942544/6300978111'; // Google test banner
  static const interstitialTestId = 'ca-app-pub-3940256099942544/1033173712';

  static Future<void> init() async {
    await MobileAds.instance.initialize();
  }
}

class BannerAdWidget extends StatefulWidget {
  const BannerAdWidget({super.key});
  @override State<BannerAdWidget> createState()=> _B();
}
class _B extends State<BannerAdWidget> {
  BannerAd? ad;
  bool loaded=false;
  @override void initState(){
    super.initState();
    ad = BannerAd(
      size: AdSize.banner,
      adUnitId: AdService.bannerTestId,
      request: const AdRequest(),
      listener: BannerAdListener(onAdLoaded: (_)=> setState(()=> loaded=true), onAdFailedToLoad: (a,e)=> a.dispose()),
    )..load();
  }
  @override void dispose(){ ad?.dispose(); super.dispose();}
  @override Widget build(BuildContext context){
    if(!loaded || ad==null) return const SizedBox(height: 50, child: Center(child: Text('Ad placeholder - banner will show here', style: TextStyle(fontSize:10, color: Colors.grey))));
    return SizedBox(height: ad!.size.height.toDouble(), child: AdWidget(ad: ad!));
  }
}
