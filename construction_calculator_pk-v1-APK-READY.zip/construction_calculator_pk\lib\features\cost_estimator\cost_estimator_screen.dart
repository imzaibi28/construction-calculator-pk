﻿import ''package:flutter/material.dart'';
import ''../../core/constants/app_colors.dart'';
import ''../../core/constants/pak_rates.dart'';
import ''../../core/utils/formulas.dart'';
import ''../../services/pdf_service.dart'';
import ''../../services/ad_service.dart'';
import ''../../widgets/common.dart'';

class CostEstimatorScreen extends StatefulWidget { const CostEstimatorScreen({super.key}); @override State<CostEstimatorScreen> createState()=> _S();}
class _S extends State<CostEstimatorScreen> {
  String city=''Lahore'';
  final cementCtrl=TextEditingController(text:''30'');
  final sandCtrl=TextEditingController(text:''400'');
  final crushCtrl=TextEditingController(text:''600'');
  final brickCtrl=TextEditingController(text:''5000'');
  final steelCtrl=TextEditingController(text:''500'');
  final paintCtrl=TextEditingController(text:''100'');
  final tilesCtrl=TextEditingController(text:''800'');
  final labourCtrl=TextEditingController(text:''30'');
  double calcTotal(){
    double c=(double.tryParse(cementCtrl.text)??0)*PakRates.forCity(PakRates.cementPerBag,city);
    double s=(double.tryParse(sandCtrl.text)??0)*PakRates.forCity(PakRates.sandPerCft,city);
    double cr=(double.tryParse(crushCtrl.text)??0)*PakRates.forCity(PakRates.crushPerCft,city);
    double b=(double.tryParse(brickCtrl.text)??0)*PakRates.forCity(PakRates.brickPerPc,city);
    double st=(double.tryParse(steelCtrl.text)??0)*PakRates.forCity(PakRates.steelPerKg,city);
    double p=(double.tryParse(paintCtrl.text)??0)*PakRates.forCity(PakRates.paintPerLiter,city);
    double t=(double.tryParse(tilesCtrl.text)??0)*85;
    double lab=(double.tryParse(labourCtrl.text)??0)*1500;
    return c+s+cr+b+st+p+t+lab;
  }
  @override Widget build(BuildContext context){
    double total=calcTotal();
    return Scaffold(backgroundColor: AppColors.bg, appBar: AppBar(title: const Text(''Cost Estimator''), backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        InputCard(label: ''City'', child: DropdownButton<String>(value: city, isExpanded: true, items: PakRates.cityMultiplier.keys.map((e)=>DropdownMenuItem(value:e, child: Text(e))).toList(), onChanged: (v)=>setState(()=>city=v!))),
        _row(''Cement (bags)'', cementCtrl, ''Rs.''+PakRates.forCity(PakRates.cementPerBag,city).toStringAsFixed(0)),
        _row(''Sand (cft)'', sandCtrl, ''Rs.''+PakRates.forCity(PakRates.sandPerCft,city).toStringAsFixed(0)),
        _row(''Crush (cft)'', crushCtrl, ''Rs.''+PakRates.forCity(PakRates.crushPerCft,city).toStringAsFixed(0)),
        _row(''Bricks'', brickCtrl, ''Rs.''+PakRates.forCity(PakRates.brickPerPc,city).toStringAsFixed(0)),
        _row(''Steel (kg)'', steelCtrl, ''Rs.''+PakRates.forCity(PakRates.steelPerKg,city).toStringAsFixed(0)),
        _row(''Tiles (sqft)'', tilesCtrl, ''Rs.85''),
        _row(''Labour (days)'', labourCtrl, ''Rs.1500''),
        const SizedBox(height:8),
        const BannerAdWidget(),
        const SizedBox(height:12),
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: AppColors.primaryDark, borderRadius: BorderRadius.circular(16)), child: Column(children:[
          const Text(''TOTAL COST'', style: TextStyle(color: Colors.white70, fontSize:11)),
          Text(PakFormulas.formatPKR(total), style: const TextStyle(color: AppColors.primary, fontSize:26, fontWeight: FontWeight.w900)),
          const SizedBox(height:12),
          SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: () async {
            var rows=[
              {''item'':''Cement'',''qty'':cementCtrl.text,''cost'':PakFormulas.formatPKR((double.tryParse(cementCtrl.text)??0)*PakRates.forCity(PakRates.cementPerBag,city))},
              {''item'':''Sand'',''qty'':sandCtrl.text,''cost'':PakFormulas.formatPKR((double.tryParse(sandCtrl.text)??0)*PakRates.forCity(PakRates.sandPerCft,city))},
              {''item'':''Bricks'',''qty'':brickCtrl.text,''cost'':PakFormulas.formatPKR((double.tryParse(brickCtrl.text)??0)*PakRates.forCity(PakRates.brickPerPc,city))},
              {''item'':''Steel'',''qty'':steelCtrl.text,''cost'':PakFormulas.formatPKR((double.tryParse(steelCtrl.text)??0)*PakRates.forCity(PakRates.steelPerKg,city))},
            ];
            await PdfService.generateAndShare(title:''Total Estimate'', city: city, rows: rows, totalPKR: PakFormulas.formatPKR(total));
          }, icon: const Icon(Icons.picture_as_pdf), label: const Text(''Generate PDF & Share''), style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary))),
        ])),
      ]));
  }
  Widget _row(String label, TextEditingController ctrl, String rate){ return InputCard(label: label+" • "+rate, child: LabeledTextField(hint: ''0'', controller: ctrl, suffix: ''qty'')); }
}
