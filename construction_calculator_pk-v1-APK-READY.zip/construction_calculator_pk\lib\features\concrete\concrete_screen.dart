import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/pak_rates.dart';
import '../../core/utils/formulas.dart';
import '../../widgets/common.dart';

class ConcreteScreen extends StatefulWidget {
  const ConcreteScreen({super.key});
  @override
  State<ConcreteScreen> createState() => _ConcreteScreenState();
}

class _ConcreteScreenState extends State<ConcreteScreen> {
  final lCtrl = TextEditingController(text: '10');
  final wCtrl = TextEditingController(text: '10');
  final hCtrl = TextEditingController(text: '0.5'); // 6 inch slab
  final lInCtrl = TextEditingController(text: '0');
  final wInCtrl = TextEditingController(text: '0');
  final hInCtrl = TextEditingController(text: '0');
  String ratio = '1:2:4';
  String city = 'Lahore';
  Map<String, double>? result;

  void calc() {
    double l = (double.tryParse(lCtrl.text) ?? 0) + (double.tryParse(lInCtrl.text) ?? 0)/12;
    double w = (double.tryParse(wCtrl.text) ?? 0) + (double.tryParse(wInCtrl.text) ?? 0)/12;
    double h = (double.tryParse(hCtrl.text) ?? 0) + (double.tryParse(hInCtrl.text) ?? 0)/12;
    List<int> r = ratio == '1:2:4' ? [1,2,4] : ratio == '1:1.5:3' ? [1,2,3] : [1,2,4]; // 1.5 approx as 2 for simplicity
    if (ratio == '1:1.5:3') r = [2,3,6]; // scaled to int
    setState(() => result = PakFormulas.concrete(l,w,h,r));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('Concrete Calculator'), backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        FeetInchInput(label: 'Length (L)', ftCtrl: lCtrl, inchCtrl: lInCtrl),
        FeetInchInput(label: 'Width (W)', ftCtrl: wCtrl, inchCtrl: wInCtrl),
        FeetInchInput(label: 'Thickness / Height (H)', ftCtrl: hCtrl, inchCtrl: hInCtrl),
        InputCard(label: 'Mix Ratio', child: DropdownButton<String>(value: ratio, isExpanded: true, items: const [DropdownMenuItem(value:'1:2:4', child: Text('1:2:4 - Normal slab/beam')), DropdownMenuItem(value:'1:1.5:3', child: Text('1:1.5:3 - Strong column/foundation'))], onChanged: (v)=>setState(()=>ratio=v!))),
        InputCard(label: 'City (for cost)', child: DropdownButton<String>(value: city, isExpanded: true, items: PakRates.cityMultiplier.keys.map((e)=>DropdownMenuItem(value:e, child: Text(e))).toList(), onChanged: (v)=>setState(()=> city=v!))),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: calc, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical:16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('CALCULATE', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)))),
        if (result != null) ...[
          const SizedBox(height: 16),
          ResultTile(title: 'Cement Bags (50kg)', value: '${result!['cementBags']!.toStringAsFixed(2)} bags', subtitle: '${result!['cementBags']!.ceil()} bags to order (+5%)', icon: Icons.inventory_2, color: const Color(0xFF6A5AE0)),
          const SizedBox(height: 10),
          ResultTile(title: 'Sand (Rait)', value: '${result!['sandCft']!.toStringAsFixed(1)} cft', subtitle: 'River sand', icon: Icons.landscape, color: const Color(0xFFD4A017)),
          const SizedBox(height: 10),
          ResultTile(title: 'Crush / Bajri', value: '${result!['crushCft']!.toStringAsFixed(1)} cft', subtitle: 'Margalla crush', icon: Icons.terrain, color: AppColors.accent),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.primaryDark, borderRadius: BorderRadius.circular(14)),
            child: Builder(builder: (_) {
              double cementCost = result!['cementBags']! * PakRates.forCity(PakRates.cementPerBag, city);
              double sandCost = result!['sandCft']! * PakRates.forCity(PakRates.sandPerCft, city);
              double crushCost = result!['crushCft']! * PakRates.forCity(PakRates.crushPerCft, city);
              double total = cementCost+sandCost+crushCost;
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('ESTIMATED COST', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1)),
                Text(PakFormulas.formatPKR(total), style: const TextStyle(color: AppColors.primary, fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('Cement ${PakFormulas.formatPKR(cementCost)} + Sand ${PakFormulas.formatPKR(sandCost)} + Crush ${PakFormulas.formatPKR(crushCost)}', style: const TextStyle(color: Colors.white70, fontSize: 11)),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: ElevatedButton.icon(onPressed: (){ final t = 'Concrete ${lCtrl.text}ft x ${wCtrl.text}ft: Cement ${result!['cementBags']!.toStringAsFixed(1)} bags, Sand ${result!['sandCft']!.toStringAsFixed(1)} cft, Crush ${result!['crushCft']!.toStringAsFixed(1)} cft - Cost ${PakFormulas.formatPKR(total)}'; Share.share(t); }, icon: const Icon(Icons.share, size:16), label: const Text('WhatsApp'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white))),
                  const SizedBox(width: 8),
                  Expanded(child: OutlinedButton.icon(onPressed: (){}, icon: const Icon(Icons.picture_as_pdf, size:16), label: const Text('PDF'), style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white24)))),
                ])
              ]);
            }),
          )
        ]
      ]),
    );
  }
}
