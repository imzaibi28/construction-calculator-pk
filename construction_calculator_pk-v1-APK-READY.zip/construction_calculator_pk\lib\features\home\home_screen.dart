import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../concrete/concrete_screen.dart';
import '../brick/brick_screen.dart';
import '../steel/steel_screen.dart';
import '../plaster/plaster_screen.dart';
import '../paint/paint_screen.dart';
import '../tiles/tiles_screen.dart';
import '../excavation/excavation_screen.dart';
import '../tank/tank_screen.dart';
import '../cost_estimator/cost_estimator_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      _HomeItem('Concrete\nSlab/Beam', 'کنکریٹ', Icons.view_in_ar, AppColors.primary, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ConcreteScreen()))),
      _HomeItem('Brick\nCalculator', 'اینٹ', Icons.wall, const Color(0xFFD44B2E), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BrickScreen()))),
      _HomeItem('Steel\nSariya', 'سریا', Icons.precision_manufacturing, const Color(0xFF3A3A3A), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SteelScreen()))),
      _HomeItem('Plaster', 'پلستر', Icons.format_paint, AppColors.accent, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlasterScreen()))),
      _HomeItem('Paint', 'پینٹ', Icons.brush, const Color(0xFF6A5AE0), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PaintScreen()))),
      _HomeItem('Tiles', 'ٹائل', Icons.grid_on, const Color(0xFF2E86AB), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TilesScreen()))),
      _HomeItem('Excavation', 'کھدائی', Icons.landscape, const Color(0xFF8B5A2B), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExcavationScreen()))),
      _HomeItem('Water Tank', 'ٹینکی', Icons.water_drop, const Color(0xFF0097A7), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TankScreen()))),
      _HomeItem('Cost\nEstimator', 'لاگت', Icons.calculate, AppColors.success, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CostEstimatorScreen()))),
    ];

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.primaryDark,
        foregroundColor: Colors.white,
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Construction Calculator', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          Text('Pakistan • PKR • Offline', style: TextStyle(fontSize: 11, color: Colors.white70)),
        ]),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.settings)),
        ],
      ),
      body: Column(children: [
        Container(
          width: double.infinity,
          color: AppColors.primary,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(children: [
            const Icon(Icons.location_on, size: 16),
            const SizedBox(width: 6),
            DropdownButton<String>(
              value: 'Lahore',
              underline: const SizedBox(),
              items: const [DropdownMenuItem(value: 'Lahore', child: Text('Lahore')), DropdownMenuItem(value: 'Karachi', child: Text('Karachi')), DropdownMenuItem(value: 'Islamabad', child: Text('Islamabad'))],
              onChanged: (_) {},
            ),
            const Spacer(),
            const Text('Rates updated: Today', style: TextStyle(fontSize: 11)),
          ]),
        ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(14),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 0.92, crossAxisSpacing: 12, mainAxisSpacing: 12),
            itemCount: items.length,
            itemBuilder: (_, i) {
              final it = items[i];
              return InkWell(
                onTap: it.onTap,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)]),
                  padding: const EdgeInsets.all(10),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: it.color.withOpacity(0.12), shape: BoxShape.circle), child: Icon(it.icon, color: it.color)),
                    const SizedBox(height: 8),
                    Text(it.title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12, height: 1.1)),
                    Text(it.subtitleUrdu, style: const TextStyle(fontSize: 10, color: AppColors.textGrey)),
                  ]),
                ),
              );
            },
          ),
        ),
      ]),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: AppColors.primaryDark,
        unselectedItemColor: AppColors.textGrey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'History'),
          BottomNavigationBarItem(icon: Icon(Icons.star), label: 'Premium'),
        ],
      ),
    );
  }

  static void _coming(BuildContext c) {
    ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('Coming in next update - v1.1')));
  }
}

class _HomeItem {
  final String title; final String subtitleUrdu; final IconData icon; final Color color; final VoidCallback onTap;
  _HomeItem(this.title, this.subtitleUrdu, this.icon, this.color, this.onTap);
}
