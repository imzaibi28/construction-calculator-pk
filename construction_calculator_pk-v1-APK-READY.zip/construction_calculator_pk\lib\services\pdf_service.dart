import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class PdfService {
  static Future<void> generateAndShare({
    required String title,
    required String city,
    required List<Map<String,String>> rows,
    required String totalPKR,
  }) async {
    final doc = pw.Document();
    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (c) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Container(
              width: double.infinity,
              padding: const pw.EdgeInsets.all(12),
              color: PdfColor.fromHex('#1A1A1A'),
              child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.Text('Construction Calculator Pakistan', style: pw.TextStyle(color: PdfColor.fromHex('#FFC600'), fontSize: 14, fontWeight: pw.FontWeight.bold)),
                pw.Text(title, style: const pw.TextStyle(color: PdfColors.white, fontSize: 18, fontWeight: pw.FontWeight.bold)),
                pw.Text('City: $city • Date: ${DateTime.now().toString().split(' ')[0]}', style: const pw.TextStyle(color: PdfColors.white, fontSize: 10)),
              ]),
            ),
            pw.SizedBox(height: 12),
            pw.Table.fromTextArray(
              headers: ['Item','Quantity','Cost (PKR)'],
              data: rows.map((r)=> [r['item']!, r['qty']!, r['cost']!]).toList(),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white),
              headerDecoration: pw.BoxDecoration(color: PdfColor.fromHex('#00A693')),
              cellPadding: const pw.EdgeInsets.all(6),
            ),
            pw.SizedBox(height: 12),
            pw.Container(
              width: double.infinity,
              padding: const pw.EdgeInsets.all(12),
              color: PdfColor.fromHex('#FFF8DC'),
              child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                pw.Text('TOTAL ESTIMATED COST', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 12)),
                pw.Text(totalPKR, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 16, color: PdfColor.fromHex('#1A1A1A'))),
              ]),
            ),
            pw.SizedBox(height: 8),
            pw.Text('Disclaimer: Rates are estimates. Confirm with local market. 1 bag cement = 50kg = 1.25 cft.', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
            pw.Text('Generated via Construction Calculator Pakistan - com.pakbuild.constructioncalculator', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
          ],
        ),
      ),
    );
    await Printing.sharePdf(bytes: await doc.save(), filename: 'construction_estimate_${DateTime.now().millisecondsSinceEpoch}.pdf');
  }
}
