import 'package:flutter/material.dart';
import 'features/home/home_screen.dart';
import 'services/ad_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AdService.init();
  runApp(const PakBuildApp());
}

class PakBuildApp extends StatelessWidget {
  const PakBuildApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Construction Calculator Pakistan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1A1A1A)),
        scaffoldBackgroundColor: const Color(0xFFF6F6F0),
        appBarTheme: const AppBarTheme(centerTitle: false),
      ),
      home: const HomeScreen(),
    );
  }
}
