import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFFFFC600); // construction yellow
  static const primaryDark = Color(0xFF1A1A1A);
  static const accent = Color(0xFF00A693); // teal trust
  static const bg = Color(0xFFF6F6F0);
  static const card = Colors.white;
  static const success = Color(0xFF1B9E3D);
  static const textDark = Color(0xFF1A1A1A);
  static const textGrey = Color(0xFF6B6B6B);
}
