import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/pak_rates.dart';
import '../../core/utils/formulas.dart';
import '../../widgets/common.dart';

class SteelScreen extends StatefulWidget {
  const SteelScreen({super.key});
  @override State<SteelScreen> createState()=> _SteelScreenState();
}
class _SteelScreenState extends State<SteelScreen> {
  final lenCtrl=TextEditingController(text:'40');
  final lenInCtrl=TextEditingController(text:'0');
  final qtyCtrl=TextEditingController(text:'4');
  String dia='12'; // mm
  String city='Lahore';
  double? weight; double? totalWeight;
  void calc(){
    double len=(double.tryParse(lenCtrl.text)??0)+(double.tryParse(lenInCtrl.text)??0)/12;
    double d=double.parse(dia);
    double w=PakFormulas.steelWeightKg(d, len);
    int q=int.tryParse(qtyCtrl.text)??1;
    setState(()=> {weight=w, totalWeight=w*q});
  }
  @override Widget build(BuildContext context){
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(title: const Text('Steel / Sariya Calculator'), backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white),
      body: ListView(padding: const EdgeInsets.all(14), children:[
        InputCard(label: 'Diameter (Sootar)', child: DropdownButton<String>(value: dia, isExpanded: true, items: const [
          DropdownMenuItem(value:'8', child: Text('8mm - #2 Sootar (rings)')),
          DropdownMenuItem(value:'10', child: Text('10mm - #3 Sootar')),
          DropdownMenuItem(value:'12', child: Text('12mm - #4 Sootar (slab/beam)')),
          DropdownMenuItem(value:'16', child: Text('16mm - #5 Sootar (column)')),
          DropdownMenuItem(value:'20', child: Text('20mm - #6 Sootar')),
          DropdownMenuItem(value:'25', child: Text('25mm - #8 Sootar')),
        ], onChanged: (v)=>setState(()=>dia=v!))),
        FeetInchInput(label: 'Length per Bar', ftCtrl: lenCtrl, inchCtrl: lenInCtrl),
        InputCard(label: 'Quantity (Bars)', child: LabeledTextField(hint: '4', controller: qtyCtrl, suffix: 'bars')),
        InputCard(label: 'City', child: DropdownButton<String>(value: city, isExpanded: true, items: PakRates.cityMultiplier.keys.map((e)=>DropdownMenuItem(value:e, child: Text(e))).toList(), onChanged: (v)=>setState(()=>city=v!))),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: calc, style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryDark, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical:16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('CALCULATE WEIGHT', style: TextStyle(fontWeight: FontWeight.w800)))),
        const SizedBox(height:8),
        Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)), child: const Text('Formula: Weight = D²/162 × Length(m) • Standard 40ft bar', style: TextStyle(fontSize:11, color: AppColors.textGrey))),
        if(weight!=null)...[
          const SizedBox(height:16),
          ResultTile(title: 'Weight per Bar', value: '${weight!.toStringAsFixed(2)} kg', subtitle: '$dia mm dia', icon: Icons.precision_manufacturing),
          const SizedBox(height:10),
          ResultTile(title: 'Total Weight', value: '${totalWeight!.toStringAsFixed(2)} kg', subtitle: '${(totalWeight!/1000).toStringAsFixed(3)} ton • ${qtyCtrl.text} bars', icon: Icons.scale, color: AppColors.primaryDark),
          const SizedBox(height:10),
          ResultTile(title: 'Weight in Maund', value: '${(totalWeight!/40).toStringAsFixed(2)} maund', subtitle: '1 maund = 40kg (Pakistan)', icon: Icons.balance),
          const SizedBox(height:10),
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.primaryDark, borderRadius: BorderRadius.circular(14)), child: Builder(builder: (_){
            double cost=totalWeight!*PakRates.forCity(PakRates.steelPerKg,city);
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
              const Text('TOTAL COST', style: TextStyle(color: Colors.white70, fontSize:11)),
              Text(PakFormulas.formatPKR(cost), style: const TextStyle(color: AppColors.primary, fontSize:22, fontWeight: FontWeight.w900)),
              Text('@ Rs.${PakRates.forCity(PakRates.steelPerKg,city).toStringAsFixed(0)}/kg in $city • Rs.${(PakRates.forCity(PakRates.steelPerKg,city)*1000).toStringAsFixed(0)}/ton', style: const TextStyle(color: Colors.white70, fontSize:11)),
              const SizedBox(height:10),
              SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: (){ Share.share('Steel $dia mm x ${lenCtrl.text}ft (${qtyCtrl.text} bars): ${totalWeight!.toStringAsFixed(2)} kg (${(totalWeight!/40).toStringAsFixed(1)} maund), Cost ${PakFormulas.formatPKR(cost)}'); }, icon: const Icon(Icons.share), label: const Text('Share on WhatsApp'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white)))
            ]);
          }))
        ]
      ]),
    );
  }
}
